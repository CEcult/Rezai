import assert from 'node:assert/strict';
import { defaultState, applyTemplate } from '../defaults.js';
import { addDays, toKey, isValidKey, daysBetween } from '../dates.js';
import { togglePractice, dayStats, syncToday, liveGoal, scheduled } from '../goals.js';
import { computeStreaks } from '../streak.js';
import { sanitize, parseBackup, exportJSON } from '../storage.js';
import { rate, weekly, monthly, frequency, heatmap } from '../stats.js';
import { monthGrid, shiftMonth } from '../calendar.js';

const today = '2026-10-12';
let s = defaultState('essencial');
const pid = (sid) => `p_r_main_${sid}`;
// DST / virada de ano
assert.equal(addDays('2026-12-31', 1), '2027-01-01');
assert.equal(addDays('2026-03-01', -1), '2026-02-28');
assert.equal(addDays('2024-03-01', -1), '2024-02-29');
assert.equal(addDays('2026-11-01', 1), '2026-11-02');
assert.equal(daysBetween('2026-01-01', '2026-12-31'), 364);
assert.ok(!isValidKey('2026-02-30'));

// marcar / desmarcar
assert.equal(liveGoal(s, today).target, 3);
assert.equal(togglePractice(s, today, pid('oracao-manha')), true);
let st = dayStats(s, today, today);
assert.equal(st.done, 1); assert.equal(st.pct, 33); assert.equal(st.met, false);
assert.equal(togglePractice(s, today, pid('oracao-manha')), false);
assert.equal(Object.keys(s.log).length, 0);
// duplicado não ocorre
togglePractice(s, today, pid('angelus')); togglePractice(s, today, pid('angelus')); assert.equal(Object.keys(s.log).length, 0);

// sequência
const mk = (k, ids) => ids.forEach((i) => togglePractice(s, k, pid(i)));
// 10 dias consecutivos terminando ontem
for (let i = 1; i <= 10; i++) mk(addDays(today, -i), ['oracao-manha']);
let r = computeStreaks(s, today);
assert.equal(r.current, 10); assert.equal(r.longest, 10); assert.equal(r.todayDone, false);
mk(today, ['oracao-manha']);
r = computeStreaks(s, today);
assert.equal(r.current, 11); assert.equal(r.todayDone, true);
// reabrir não duplica
mk(today, ['oracao-manha']); mk(today, ['oracao-manha']); // liga/desliga/liga? two toggles => off,on... 
r = computeStreaks(s, today); assert.equal(r.current, 11);
// quebra: remove ontem
togglePractice(s, addDays(today, -1), pid('oracao-manha'));
r = computeStreaks(s, today);
assert.equal(r.current, 1); assert.equal(r.longest, 9);
// dia passado sem nada: 2 dias sem registro => current 0, recorde preservado
togglePractice(s, today, pid('oracao-manha'));
r = computeStreaks(s, today);
assert.equal(r.current, 0); assert.equal(r.longest, 9);
assert.ok(r.runs.at(-1).ended.missed >= 2);
// marcos
assert.equal(r.milestones.find((m) => m.days === 7).achievedOn, addDays(today, -10 + 6));
assert.equal(r.milestones.find((m) => m.days === 14).achievedOn, null);

// meta concluída + essencial
s = defaultState('essencial');
mk(today, ['oracao-manha', 'angelus', 'oracao-noite']);
st = dayStats(s, today, today); assert.equal(st.met, true); assert.equal(st.pct, 100);
// mudar meta não reescreve passado
s.log['2026-10-10'] = { entries: { a: { at: null, name: 'x', counts: true, manual: true } }, goal: { target: 1, requiredIds: [], available: 4 } };
s.settings.goalCount = 4;
assert.equal(dayStats(s, '2026-10-10', today).met, true);
syncToday(s, today);
assert.equal(dayStats(s, today, today).target, 4);
assert.equal(dayStats(s, today, today).met, false);

// recorrência semanal: 2026-10-12 é segunda
const p = s.practices.find((x) => x.sid === 'angelus'); p.days = [0];
assert.ok(!scheduled(s, today).some((x) => x.sid === 'angelus'));
assert.ok(scheduled(s, '2026-10-11').some((x) => x.sid === 'angelus')); // domingo
// rotina especial no domingo
s.routines.push({ id: 'r_dom', name: 'Domingo', weekdays: [0] });
s.practices.push({ id: 'q1', routineId: 'r_dom', name: 'Missa', desc: '', icon: 'church', period: 'manha', time: '', days: [], active: true, counts: true, required: false, notify: true, order: 1 });
assert.deepEqual(scheduled(s, '2026-10-11').map((x) => x.name), ['Missa']);

// obrigatórias
s = defaultState('essencial');
s.practices.find((x) => x.sid === 'oracao-noite').required = true;
mk(today, ['oracao-manha', 'angelus', 'acao-gracas']);
assert.equal(dayStats(s, today, today).met, false);
assert.equal(dayStats(s, today, today).requiredMissing, 1);

// backup roundtrip + inválidos
s = defaultState('tradicional'); mk('2026-10-01', ['oracao-manha']);
const ex = exportJSON(s);
const back = parseBackup(ex); assert.ok(back.ok); assert.deepEqual(Object.keys(back.state.log), ['2026-10-01']);
assert.ok(!parseBackup('nao json').ok);
assert.ok(!parseBackup('{"foo":1}').ok);
assert.ok(!parseBackup('[]').ok);
assert.ok(!parseBackup(JSON.stringify({ app: 'rezai', data: { version: 99, practices: [], log: {} } })).ok);
const hostile = parseBackup(JSON.stringify({ practices: [{ id: 'a', name: '  X  ', icon: 'zzz', period: 'x', time: '99:99', days: [9, 1, 1] }, { id: 'a', name: 'dup' }, { name: 'sem id' }], log: { '2026-02-30': { entries: { a: {} } }, '2999-01-01': { entries: { a: { name: 'f' } } }, '2026-10-02': { entries: { a: { at: 'lixo', name: 5 } } } }, routines: 'x' }));
assert.ok(hostile.ok);
assert.equal(hostile.state.practices.length, 1); assert.equal(hostile.state.practices[0].icon, 'star'); assert.equal(hostile.state.practices[0].time, ''); assert.deepEqual(hostile.state.practices[0].days, [1]);
assert.deepEqual(Object.keys(hostile.state.log), ['2026-10-02']);
// template
s = defaultState('essencial'); applyTemplate(s, 'r_main', 'tradicional');
assert.equal(s.practices.filter((x) => x.active).length, 7);

// stats / calendar não quebram
s = defaultState(); for (let i = 0; i < 20; i++) mk(addDays(today, -i), ['oracao-manha', 'angelus', 'oracao-noite']);
console.log(rate(s, today, 7), rate(s, today, 30), weekly(s, today).length, monthly(s, today).at(-1), frequency(s)[0], heatmap(s, today).length);
const g = monthGrid(s, 2026, 9, today); assert.equal(g.length, 4 + 31); // 1/out/2026 = quinta
assert.deepEqual(shiftMonth(2026, 0, -1), { y: 2025, m: 11 }); assert.deepEqual(shiftMonth(2026, 11, 1), { y: 2027, m: 0 });
console.log('TODOS OS TESTES PASSARAM');
